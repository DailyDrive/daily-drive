import { NextResponse } from 'next/server'
import { chatReply } from '../../../lib/ai'
import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

export async function POST(req){
  try{
    const body = await req.json()
    const text = await chatReply(body.prompt, { tone: body.tone || 'Encouraging' })
    // save chat if session cookie exists - NextAuth stores session server-side; for simplicity, skip linking here.
    try {
      // optional: persist to DB if user email provided
      if (body.email) {
        await prisma.chat.create({ data: { userId: null, prompt: body.prompt, response: text } })
      }
    } catch(e){ console.error('db save err', e) }
    return NextResponse.json({ text })
  } catch(e){
    console.error(e)
    return NextResponse.json({ error:'AI error' }, { status:500 })
  }
}
