import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import { getServerSession } from 'next-auth'
import { authOptions } from '../auth/[...nextauth]/route'
import { PrismaClient } from '@prisma/client'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)
const prisma = new PrismaClient()

export async function POST(req) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) return NextResponse.json({ error: 'not_authenticated' }, { status: 401 })

    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) return NextResponse.json({ error: 'user_not_found' }, { status: 404 })

    const subscription = await prisma.subscription.findFirst({ where: { userId: user.id } })
    if (!subscription?.stripeCustomer) return NextResponse.json({ error: 'no_customer' }, { status: 400 })

    const portalSession = await stripe.billingPortal.sessions.create({
      customer: subscription.stripeCustomer,
      return_url: `${process.env.NEXT_PUBLIC_SITE_URL}/account`
    })

    return NextResponse.json({ url: portalSession.url })
  } catch (err) {
    console.error('portal error', err)
    return NextResponse.json({ error: err.message || 'stripe error' }, { status: 500 })
  }
}
