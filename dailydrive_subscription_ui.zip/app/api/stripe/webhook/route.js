import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)

export async function POST(req) {
  const buf = await req.arrayBuffer()
  const rawBody = Buffer.from(buf)
  const sig = req.headers.get('stripe-signature')
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET
  let event

  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, webhookSecret)
  } catch (err) {
    console.error('Webhook signature verification failed.', err.message)
    return NextResponse.json({ error: 'invalid_signature' }, { status: 400 })
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object
        const customerId = session.customer
        const subscriptionId = session.subscription
        const userEmail = session.metadata?.userEmail

        // Fetch subscription from Stripe to get price info
        const sub = await stripe.subscriptions.retrieve(subscriptionId)
        const priceId = sub.items?.data?.[0]?.price?.id
        const status = sub.status

        if (userEmail) {
          // find user and upsert subscription record
          const user = await prisma.user.findUnique({ where: { email: userEmail } })
          if (user) {
            await prisma.subscription.create({
              data: {
                userId: user.id,
                stripeCustomer: customerId,
                stripeSubId: subscriptionId,
                status: status,
                priceId: priceId
              }
            })
            console.log('Created subscription record for', userEmail)
          }
        }
        break
      }

      case 'customer.subscription.updated':
      case 'customer.subscription.created': {
        const subscription = event.data.object
        const stripeSubId = subscription.id
        const stripeCustomer = subscription.customer
        const status = subscription.status
        const priceId = subscription.items?.data?.[0]?.price?.id

        // find subscription in DB and update or create
        const existing = await prisma.subscription.findFirst({ where: { stripeSubId } })
        if (existing) {
          await prisma.subscription.update({
            where: { id: existing.id },
            data: { status, priceId, stripeCustomer }
          })
        } else {
          // try to associate by customer id
          const byCustomer = await prisma.subscription.findFirst({ where: { stripeCustomer } })
          if (byCustomer) {
            await prisma.subscription.update({
              where: { id: byCustomer.id },
              data: { stripeSubId, status, priceId }
            })
          } else {
            // create orphaned record
            await prisma.subscription.create({
              data: { stripeCustomer, stripeSubId, status, priceId }
            })
          }
        }
        break
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object
        const stripeSubId = subscription.id
        const existing = await prisma.subscription.findFirst({ where: { stripeSubId } })
        if (existing) {
          await prisma.subscription.update({
            where: { id: existing.id },
            data: { status: 'canceled' }
          })
        }
        break
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object
        const stripeCustomer = invoice.customer
        // Optionally flag the subscription for payment failure
        const existing = await prisma.subscription.findFirst({ where: { stripeCustomer } })
        if (existing) {
          await prisma.subscription.update({
            where: { id: existing.id },
            data: { status: 'past_due' }
          })
        }
        break
      }

      default:
        console.log(`Unhandled webhook event type: ${event.type}`)
    }

    return NextResponse.json({ received: true })
  } catch (err) {
    console.error('webhook handler error', err)
    return NextResponse.json({ error: 'handler_error' }, { status: 500 })
  }
}
