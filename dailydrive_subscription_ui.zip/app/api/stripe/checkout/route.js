import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import { getServerSession } from 'next-auth'
import { authOptions } from '../../auth/[...nextauth]/route'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)

export async function POST(req){
  try {
    const session = await getServerSession(authOptions)
    if (!session) return NextResponse.json({ error: 'not_authenticated' }, { status: 401 })

    const body = await req.json()
    // Allow specifying plan via body.priceId, otherwise use env defaults
    const priceId = body?.priceId || process.env.STRIPE_PRICE_ID_MONTHLY || process.env.STRIPE_PRICE_ID_YEARLY
    if (!priceId) return NextResponse.json({ error: 'missing_price_id' }, { status: 400 })

    // Ensure Stripe customer exists for this user
    let customerId = null
    // Check in DB for existing stripeCustomer for the user
    const userEmail = session.user.email
    const user = await prisma.user.findUnique({ where: { email: userEmail } })
    if (user) {
      // find subscription record with stripeCustomer if exists
      const sub = await prisma.subscription.findFirst({ where: { userId: user.id, stripeCustomer: { not: null } } })
      if (sub && sub.stripeCustomer) customerId = sub.stripeCustomer
    }

    if (!customerId) {
      // create new Stripe customer
      const customer = await stripe.customers.create({
        email: userEmail,
        metadata: { userId: user ? user.id : 'unknown' }
      })
      customerId = customer.id
      // persist to DB (create or update one subscription record placeholder)
      if (user) {
        await prisma.subscription.create({
          data: {
            userId: user.id,
            stripeCustomer: customerId,
            status: 'pending',
            priceId: priceId
          }
        })
      }
    }

    // Create Checkout session
    const sessionCheckout = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      customer: customerId,
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/account?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/account?canceled=1`,
      metadata: {
        userEmail: userEmail
      }
    })

    return NextResponse.json({ url: sessionCheckout.url })
  } catch (err) {
    console.error('checkout error', err)
    return NextResponse.json({ error: err.message || 'stripe error' }, { status: 500 })
  }
}
