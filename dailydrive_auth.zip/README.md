# Daily Drive — Next.js + NextAuth + Prisma Starter

This scaffold includes:
- Next.js App Router
- NextAuth (Email provider) configured with Prisma adapter
- Prisma schema for Postgres
- AI endpoints for spark & chat (uses OpenAI)
- Simple client pages for sign-in and chat

## Quickstart (local)

1. Install:
   ```
   npm install
   npx prisma generate
   ```
2. Copy `.env.example` to `.env.local` and set real values (DATABASE_URL, SMTP_URL, NEXTAUTH_SECRET, OPENAI_API_KEY).
3. Initialize DB:
   ```
   npx prisma migrate dev --name init
   ```
4. Run dev:
   ```
   npm run dev
   ```
5. Open http://localhost:3000

## Notes
- This is a starter. Add production configs: Vercel env vars, rate limiting, monitoring, stronger moderation, and webhook handling.
- For deployment, set NEXTAUTH_URL and NEXTAUTH_SECRET, configure your Postgres and SMTP provider.
