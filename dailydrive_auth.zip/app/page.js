import Link from 'next/link'
import { getServerSession } from 'next-auth'
import { authOptions } from './api/auth/[...nextauth]/route'

export default async function Page(){
  const session = await getServerSession(authOptions)
  return (
    <main style={{maxWidth:960, margin:'28px auto', padding:20}}>
      <header style={{background:'linear-gradient(90deg,#7c3aed,#4c1d95)', color:'white', padding:28, borderRadius:12}}>
        <h1 style={{margin:0}}>Daily Drive</h1>
        <p style={{marginTop:8}}>Your AI motivator — tiny plans, big wins.</p>
      </header>

      <section style={{display:'flex', gap:20, marginTop:20}}>
        <div style={{flex:1, background:'white', padding:18, borderRadius:10}}>
          <h2>Daily Spark</h2>
          <p>One short line + one micro-task.</p>
          <Link href="/app/spark"><a style={{padding:'10px 14px', background:'#7c3aed', color:'white', borderRadius:8}}>Get a spark</a></Link>
        </div>
        <div style={{width:320, background:'white', padding:18, borderRadius:10}}>
          <h3>Account</h3>
          {session ? (
            <>
              <p>Signed in as {session.user.email}</p>
              <form action="/api/auth/signout" method="post">
                <button type="submit" style={{padding:8, background:'#ef4444', color:'white', borderRadius:6}}>Sign out</button>
              </form>
            </>
          ) : (
            <>
              <Link href="/auth/signin"><a style={{display:'inline-block', padding:8, background:'#10b981', color:'white', borderRadius:6}}>Sign in / Sign up</a></Link>
            </>
          )}
        </div>
      </section>
    </main>
  )
}
