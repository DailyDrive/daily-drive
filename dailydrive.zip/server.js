// Minimal Express backend for Daily Drive
// Run: npm install
// Set environment variables as in .env.example, then: npm run dev

const express = require('express')
const bodyParser = require('body-parser')
const fetch = require('node-fetch')
const Stripe = require('stripe')
const cors = require('cors')
const path = require('path')

const app = express()
app.use(cors())
app.use(bodyParser.json())
app.use(express.static(path.join(__dirname, 'public')))

const OPENAI_KEY = process.env.OPENAI_API_KEY || ''
const STRIPE_KEY = process.env.STRIPE_SECRET_KEY || ''
const stripe = STRIPE_KEY ? Stripe(STRIPE_KEY) : null

app.post('/api/generate-spark', async (req, res) => {
  try {
    // Use OpenAI Chat Completions - replace with your provider/SDK if needed.
    if (!OPENAI_KEY) {
      // fallback text if no key provided
      return res.json({ text: "You’re capable — do one small thing now: write the first sentence of your plan." })
    }
    const prompt = `Write a 1-line motivational hook followed by a 1-sentence micro-task. Tone: encouraging.`
    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${OPENAI_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{role:'system', content:'You are a short motivational assistant.'},{role:'user', content: prompt}],
        max_tokens: 80
      })
    })
    const j = await r.json()
    const text = j?.choices?.[0]?.message?.content || "You’ve got this — do one small thing now."
    res.json({ text })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'AI generation error' })
  }
})

app.post('/api/chat', async (req, res) => {
  const { prompt, tone = 'Encouraging' } = req.body || {}
  if (!prompt) return res.status(400).json({ error: 'missing prompt' })
  try {
    if (!OPENAI_KEY) {
      return res.json({ text: "Pretend AI reply (no OPENAI_KEY set). Tip: set OPENAI_KEY env var to enable real replies." })
    }
    const system = `You are a warm, concise motivational coach. Tone preference: ${tone}. Provide a 3-step micro-plan and a quick first-step to do now.`
    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${OPENAI_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{role:'system', content: system}, {role:'user', content: prompt}],
        max_tokens: 300
      })
    })
    const j = await r.json()
    const text = j?.choices?.[0]?.message?.content || "Try doing the first minute: ... "
    res.json({ text })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'AI chat error' })
  }
})

// Simple signup stub - store emails using your chosen DB / mailing service
app.post('/api/signup', (req, res) => {
  const { email } = req.body || {}
  if (!email) return res.status(400).json({ error: 'missing email' })
  console.log('New signup:', email)
  // Ideally save to DB and send welcome email via SendGrid
  res.json({ ok: true })
})

// Create Stripe Checkout session (priceId expected). Requires STRIPE_SECRET_KEY env var.
app.post('/api/create-checkout', async (req, res) => {
  if (!stripe) return res.status(500).json({ error: 'Stripe not configured' })
  const { priceId } = req.body || {}
  if (!priceId) return res.status(400).json({ error: 'missing priceId' })
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: (process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000') + '/?success=1',
      cancel_url: (process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000') + '/?canceled=1',
    })
    res.json({ url: session.url })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: err.message })
  }
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => console.log(`Daily Drive server listening on ${PORT}`))
