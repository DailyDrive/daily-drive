# Daily Drive — Minimal AI Motivation Starter

This is a minimal, ready-to-run starter project for **Daily Drive**, an AI-powered motivation website.

## What's included
- Static frontend: `public/index.html`
- Express backend: `server.js`
- API endpoints:
  - `POST /api/generate-spark` — returns a short motivational spark
  - `POST /api/chat` — AI coach chat (requires OpenAI API key)
  - `POST /api/signup` — email signup stub
  - `POST /api/create-checkout` — creates Stripe Checkout session (requires Stripe key)

## Setup (local)
1. Install dependencies:
   ```
   npm install
   ```
2. Copy `.env.example` to `.env` and add your `OPENAI_API_KEY` and/or `STRIPE_SECRET_KEY`.
3. Run the server:
   ```
   npm run dev
   ```
4. Open http://localhost:3000

## Notes
- No API keys are included. Use environment variables.
- This starter is intentionally minimal; replace the signup stub with a real DB and email service.
- For production, add authentication, database, rate limiting, and proper error handling.

## Next recommended steps
- Connect SendGrid or Postgres for signups
- Add Stripe product & price IDs and configure webhook
- Harden security (helmet, rate limiting)
- Add moderation filters for sensitive prompts
