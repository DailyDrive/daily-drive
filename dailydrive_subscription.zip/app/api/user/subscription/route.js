import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '../../auth/[...nextauth]/route'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session) return NextResponse.json({ error: 'not_authenticated' }, { status: 401 })

    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) return NextResponse.json({ error: 'user_not_found' }, { status: 404 })

    const subscription = await prisma.subscription.findFirst({ where: { userId: user.id }, orderBy: { createdAt: 'desc' } })
    if (!subscription) return NextResponse.json({ status: 'none' })

    return NextResponse.json({
      status: subscription.status,
      priceId: subscription.priceId,
      stripeCustomer: subscription.stripeCustomer,
      stripeSubId: subscription.stripeSubId
    })
  } catch (err) {
    console.error('subscription api error', err)
    return NextResponse.json({ error: 'server_error' }, { status: 500 })
  }
}
