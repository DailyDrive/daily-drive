'use client'
import { useState, useEffect } from 'react'

export default function AccountPage() {
  const [user, setUser] = useState(null)
  const [subscription, setSubscription] = useState(null)
  const [plans, setPlans] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    // Fetch session info from NextAuth
    fetch('/api/auth/session').then(res => res.json()).then(data => {
      if (data?.user) setUser(data.user)
    })
    // Optionally fetch subscription info (custom endpoint or extend session)
    fetch('/api/user/subscription').then(res => res.json()).then(data => {
      if (data?.status) setSubscription(data)
    })
    // Fetch dynamic plans from Stripe
    fetch('/api/stripe/plans').then(res => res.json()).then(data => {
      if (Array.isArray(data)) setPlans(data)
    })
  }, [])

  async function startCheckout(priceId) {
    setLoading(true)
    const res = await fetch('/api/stripe/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ priceId })
    })
    const data = await res.json()
    if (data.url) window.location.href = data.url
    setLoading(false)
  }

  async function manageBilling() {
    const res = await fetch('/api/stripe/portal', { method: 'POST' })
    const data = await res.json()
    if (data.url) window.location.href = data.url
  }

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Account</h1>
      {user ? <p>Signed in as <b>{user.email}</b></p> : <p>Loading user...</p>}

      {subscription ? (
        <div>
          <p>Subscription status: <b>{subscription.status}</b></p>
          {subscription.status === 'active' ? (
            <button onClick={manageBilling}>Manage Billing</button>
          ) : (
            <div>
              <button disabled={loading} onClick={() => startCheckout(process.env.NEXT_PUBLIC_PRICE_ID_MONTHLY)}>Go Pro Monthly</button>
              <button disabled={loading} onClick={() => startCheckout(process.env.NEXT_PUBLIC_PRICE_ID_YEARLY)}>Go Pro Yearly</button>
            </div>
          )}
        </div>
      ) : (
        <div>
          <p>No subscription yet.</p>
          <button disabled={loading} onClick={() => startCheckout(process.env.NEXT_PUBLIC_PRICE_ID_MONTHLY)}>Go Pro Monthly</button>
          <button disabled={loading} onClick={() => startCheckout(process.env.NEXT_PUBLIC_PRICE_ID_YEARLY)}>Go Pro Yearly</button>

          <h3>Other Plans:</h3>
          {plans.map(plan => (
            <div key={plan.id}>
              <p>{plan.product.name} — {(plan.unit_amount / 100).toFixed(2)} {plan.currency.toUpperCase()} / {plan.recurring?.interval}</p>
              <button disabled={loading} onClick={() => startCheckout(plan.id)}>Choose</button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
