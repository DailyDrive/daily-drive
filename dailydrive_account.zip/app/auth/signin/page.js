'use client'
import { useState } from 'react'

export default function SignIn(){
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)

  async function submit(e){
    e.preventDefault()
    const res = await fetch('/api/auth/signin/email', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email})})
    if (res.ok) setSent(true)
  }

  return (
    <main style={{maxWidth:600, margin:'60px auto', padding:20}}>
      <h1>Sign in / Sign up</h1>
      <form onSubmit={submit} style={{display:'flex', gap:8, flexDirection:'column'}}>
        <input placeholder="Your email" value={email} onChange={e=>setEmail(e.target.value)} />
        <button type="submit" style={{background:'#7c3aed', color:'white', padding:10, borderRadius:8}}>Send sign-in link</button>
      </form>
      {sent && <p>Check your email for a sign-in link.</p>}
    </main>
  )
}
