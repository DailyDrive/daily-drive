import { NextResponse } from 'next/server'
import { generateSpark } from '../../../lib/ai'

export async function POST(){
  try {
    const text = await generateSpark()
    return NextResponse.json({ text })
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'AI error' }, { status: 500 })
  }
}
