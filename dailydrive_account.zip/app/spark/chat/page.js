'use client'
import { useState } from 'react'

export default function ChatPage(){
  const [prompt, setPrompt] = useState('')
  const [messages, setMessages] = useState([{role:'assistant', text:"Hi — I'm Daily Drive. What's one small win you'd like?"}])
  const [loading, setLoading] = useState(false)

  async function send(){
    if (!prompt) return
    const user = {role:'user', text: prompt}
    setMessages(m=>[...m, user])
    setPrompt('')
    setLoading(true)
    try {
      const res = await fetch('/api/chat', {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({prompt})})
      const j = await res.json()
      setMessages(m=>[...m, {role:'assistant', text: j.text}])
    } catch(e){
      setMessages(m=>[...m, {role:'assistant', text:'Error: try again.'}])
    } finally { setLoading(false) }
  }

  return (
    <main style={{maxWidth:800, margin:'28px auto', padding:20}}>
      <div style={{background:'white', padding:16, borderRadius:10}}>
        <div style={{minHeight:240, maxHeight:480, overflow:'auto', padding:8, border:'1px solid #e6eef8', borderRadius:8}}>
          {messages.map((m,i)=>(
            <div key={i} style={{margin:8, textAlign: m.role==='user' ? 'right' : 'left'}}>{m.text}</div>
          ))}
        </div>
        <div style={{display:'flex', gap:8, marginTop:10}}>
          <input value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Type your goal..." style={{flex:1}} />
          <button onClick={send} style={{background:'#7c3aed', color:'white', padding:'8px 12px', borderRadius:6}} disabled={loading}>{loading ? '...' : 'Send'}</button>
        </div>
      </div>
    </main>
  )
}
