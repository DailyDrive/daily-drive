import { getServerSession } from 'next-auth'
import { authOptions } from '../api/auth/[...nextauth]/route'
import Link from 'next/link'

export default async function Page(){
  const session = await getServerSession(authOptions)
  return (
    <main style={{maxWidth:720, margin:'28px auto', padding:20}}>
      <div style={{background:'white', padding:18, borderRadius:10}}>
        <h2>AI Coach / Spark</h2>
        <p>Use the AI coach to generate a micro-plan.</p>
        {session ? (
          <div>
            <p>Signed in as {session.user.email}</p>
            <a href="/app/spark/chat" style={{display:'inline-block', padding:10, background:'#7c3aed', color:'white', borderRadius:8}}>Open chat</a>
          </div>
        ) : (
          <div>
            <p>Please <Link href="/auth/signin"><a style={{color:'#7c3aed'}}>sign in</a></Link> to save your chats and access Pro features.</p>
          </div>
        )}
      </div>
    </main>
  )
}
