# Daily Drive — Next.js + NextAuth + Prisma Starter

This scaffold includes:
- Next.js App Router
- NextAuth (Email provider) configured with Prisma adapter
- Prisma schema for Postgres
- AI endpoints for spark & chat (uses OpenAI)
- Simple client pages for sign-in and chat

## Quickstart (local)

1. Install:
   ```
   npm install
   npx prisma generate
   ```
2. Copy `.env.example` to `.env.local` and set real values (DATABASE_URL, SMTP_URL, NEXTAUTH_SECRET, OPENAI_API_KEY).
3. Initialize DB:
   ```
   npx prisma migrate dev --name init
   ```
4. Run dev:
   ```
   npm run dev
   ```
5. Open http://localhost:3000

## Notes
- This is a starter. Add production configs: Vercel env vars, rate limiting, monitoring, stronger moderation, and webhook handling.
- For deployment, set NEXTAUTH_URL and NEXTAUTH_SECRET, configure your Postgres and SMTP provider.


## Stripe setup (subscriptions)

1. In Stripe Dashboard create a Product (e.g., "Daily Drive Pro") and create recurring Prices (monthly and/or yearly).
2. Add the price IDs to your `.env.local`:
   ```
   STRIPE_SECRET_KEY=sk_test_...
   STRIPE_WEBHOOK_SECRET=whsec_...
   STRIPE_PRICE_ID_MONTHLY=price_...
   STRIPE_PRICE_ID_YEARLY=price_...
   ```
3. Start your app (`npm run dev`) and expose a public webhook endpoint (use Stripe CLI for local testing):
   ```
   stripe listen --forward-to localhost:3000/api/stripe/webhook
   ```
4. Use the client to call `/api/stripe/checkout` (POST) with `{ priceId }` or click "Go Pro" button to trigger checkout for the logged-in user.
5. The webhook will handle `checkout.session.completed`, `customer.subscription.*`, and `invoice.payment_failed` to sync subscription state.


## Billing Portal

Users can manage their subscription (cancel, update card) via Stripe's customer portal.

- API: `/api/stripe/portal`
- Account page shows a "Manage Billing" button when a subscription is active.

